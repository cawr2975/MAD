package net.calebwright.finalexam;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.annotation.DrawableRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText pizzaName;
    Button sauceButton;
    Button doneButton;
    Boolean isRed = true;
    ImageView pizzaImageView;
    String siteURL;
    String siteName;
    CheckBox cheeseCheckBox;
    CheckBox pepperCheckBox;
    CheckBox glutenFreeCheckBox;
    CheckBox meatLoversCheckBox;
    Boolean meat;
    Boolean pepper;
    Boolean cheese;
    Boolean glutenFree;
    Spinner sizeSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUpButtons();
        meat = false;
        pepper = false;
        cheese = false;
        glutenFree = false;
    }
    private void setUpButtons(){

        siteName = "BackCountry Pizza and Taphouse";
        siteURL = "https://backcountrypizzaandtaphouse.info/";
        sizeSpinner = findViewById(R.id.sizeSpinner);
        cheeseCheckBox = findViewById(R.id.cheeseCheck);
        glutenFreeCheckBox = findViewById(R.id.glutenFreeCheck);
        pepperCheckBox = findViewById(R.id.pepperCheck);
        meatLoversCheckBox = findViewById(R.id.meatLoversCheck);
        pizzaImageView = findViewById(R.id.pizza_image_view);
        pizzaImageView.setVisibility(View.INVISIBLE);
        pizzaName = findViewById(R.id.editTextPizzaName);
        pizzaName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPizzaName();
            }
        });
        sauceButton = findViewById(R.id.SauceType);
        doneButton = findViewById(R.id.generatePizzaButton);
        // declare on-click listeners for buttons
        sauceButton.setOnClickListener(new View.OnClickListener() { // for some reason my computer has issues with toggle buttons, so I decided to code my own. Hope that works.
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Sauce Button Clicked", Toast.LENGTH_SHORT).show();
                if(isRed == true){
                    sauceButton.setText("Red Sauce");
                    isRed = false;
                    return;
                }
                else{
                    sauceButton.setText("White Sauce");
                    isRed = true;
                    return;
                }
            }
        });
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pizzaSize = sizeSpinner.getSelectedItem().toString();
                Toast.makeText(MainActivity.this, "Generate Button Clicked", Toast.LENGTH_SHORT).show();
                // launch a new explicit/implicit intent to take them to a new web page
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                intent.putExtra("siteURL", siteURL);
                intent.putExtra("siteName", siteName);
                intent.putExtra("pizzaSize", pizzaSize);
                startActivity(intent);
            }
        });

    }
    private void updateImage(){
        pizzaImageView.setVisibility(View.VISIBLE);
        Toast.makeText(MainActivity.this, "I wanted to update the image here, but I couldn't figure it out in time", Toast.LENGTH_LONG).show();
    }
    private void setPizzaName(){
        String content = pizzaName.getText().toString();
        pizzaName.setText(content);
//        doneButton.setText("Take me to " + content);

        // couldn't quite get it to work. I think I was close.
    }
    public void onCheckboxClicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        switch(view.getId()) {
            case R.id.meatLoversCheck:
                if (checked){
                    meat = true;
                    siteName = "Boss Lady Pizza";
                    siteURL = "http://www.bossladypizza.com";
//                    Toast.makeText(MainActivity.this, "Meat is true", Toast.LENGTH_SHORT).show();
                }
            else{
                    meat = false;
//                    Toast.makeText(MainActivity.this, "Meat is false", Toast.LENGTH_SHORT).show();
                }
                updateImage();
                break;
            case R.id.pepperCheck:
                if (checked){
                    pepper = true;
                    siteName = "Pizzaria Locale";
                    siteURL = "https://localeboulder.com/"; // for some reason it doesn't work with locale... Not sure why... // Update: I had a space before the URL. Fixed it.
//                    Toast.makeText(MainActivity.this, "Pepper is true", Toast.LENGTH_SHORT).show();
                }
            else{
                    pepper = false;
//                    Toast.makeText(MainActivity.this, "Pepper is false", Toast.LENGTH_SHORT).show();
                }
                updateImage();
                break;
            case R.id.glutenFreeCheck:
                if (checked){
                    glutenFree = true;
                    siteName = "Boss Lady Pizza";
                    siteURL = "http://www.bossladypizza.com";
//                    Toast.makeText(MainActivity.this, "Gluten Free is true", Toast.LENGTH_SHORT).show();
                }
                else{
                    glutenFree = false;
//                    Toast.makeText(MainActivity.this, "Gluten Free is false", Toast.LENGTH_SHORT).show();
                }
                updateImage();
                break;
            case R.id.cheeseCheck:
                if (checked){
                    cheese = true;
                    siteName = "BackCountry Pizza and Taphouse";
                    siteURL = "https://backcountrypizzaandtaphouse.info/";
//                    Toast.makeText(MainActivity.this, "Cheese is true", Toast.LENGTH_SHORT).show();
                }
                else{
                    cheese = false;
//                    Toast.makeText(MainActivity.this, "Cheese is false", Toast.LENGTH_SHORT).show();
                }
                updateImage();
                break;
        }
    }

}
