package net.calebwright.finalexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
//import android.net.Uri;
import static android.provider.CalendarContract.CalendarCache.URI;

//import java.net.URI;

public class Main2Activity extends AppCompatActivity {
    private String siteURL;
    private String siteName;
    String pizzaSize;
    Button loadButton;
    TextView youShouldTry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();
        siteURL = intent.getStringExtra("siteURL");
        siteName = intent.getStringExtra("siteName");
        pizzaSize = intent.getStringExtra("pizzaSize");
        Toast.makeText(Main2Activity.this, "Intent Successfully Launched", Toast.LENGTH_SHORT).show();
        setUpGoButton();
        youShouldTry = findViewById(R.id.youShouldTryTV);
        youShouldTry.setText("You Should Try " + siteName + ". I have heard they have good " + pizzaSize + " pizzas there!");
        // set a text message here to say the name of the site they should go to...
    }
    private void setUpGoButton(){
        loadButton = findViewById(R.id.goButton);
        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main2Activity.this, "Go Button successfully Clicked", Toast.LENGTH_SHORT).show();
                loadSite(v);
            }
        });
    }
    private void loadSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(URI.parse(siteURL));
        startActivity(intent);
        Toast.makeText(Main2Activity.this, "This should then take the user to the site", Toast.LENGTH_SHORT).show();
    }
}
