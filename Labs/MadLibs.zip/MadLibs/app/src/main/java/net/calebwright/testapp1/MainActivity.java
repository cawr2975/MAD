package net.calebwright.testapp1;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Pulled mad lib template from https://www.woojr.com/mad-libs-worksheets/school-mad-libs-recess/
    String _noun = "a";
    String _noun2 = "a";
    String _adjective = "a";
    String _adjective2 = "a";
    String _food = "a";
    String _bodypart = "a";
    String _verb = "a";
    String _verb2 = "a";
    int counter = 0;
    int radioCounter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toast welcomeToast = Toast.makeText(getApplicationContext(), "Welcome!", Toast.LENGTH_LONG);
        welcomeToast.show();

        final EditText noun = (EditText) findViewById(R.id.noun);
        final EditText noun2 = (EditText) findViewById(R.id.plural_noun);
        final EditText adjective = (EditText) findViewById(R.id.adjective1);
        final EditText adjective2 = (EditText) findViewById(R.id.adjective2);
        final EditText food = (EditText) findViewById(R.id.food);
        final EditText bodypart = (EditText) findViewById(R.id.body_part);
        final EditText verb = (EditText) findViewById(R.id.verb1);
        final EditText verb2 = (EditText) findViewById(R.id.verb2);
        final Spinner dropDown = (Spinner) findViewById(R.id.drop_down);
        final CheckBox beHappyCheck = (CheckBox) findViewById(R.id.be_happy_check);
        final ImageView smileyImage = (ImageView) findViewById(R.id.imageView);
        final RadioButton darkTheme = (RadioButton) findViewById(R.id.light_view_radio);
        final Switch textColorSwitch = (Switch) findViewById(R.id.color_switch);
        smileyImage.setVisibility(View.INVISIBLE);

        textColorSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(counter == 1){
                    getWindow().getDecorView().setBackgroundColor(Color.WHITE);
                    counter = 0;
                }
                else{
                    getWindow().getDecorView().setBackgroundColor(Color.LTGRAY);
                    counter = 1;
                }
            }
        });
        darkTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(radioCounter == 1){
                    Toast checkBoxToast = Toast.makeText(getApplicationContext(), "Wanted to change the background color, but couldn't figure it out", Toast.LENGTH_LONG);
                    checkBoxToast.show();
                    radioCounter = 0;
                }
                else{
                    darkTheme.setChecked(false);
                    Toast checkOffToast = Toast.makeText(getApplicationContext(), "Radio Button off", Toast.LENGTH_LONG);
                    checkOffToast.show();
                    radioCounter = 1;
                }
            }
        });

        beHappyCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(beHappyCheck.isChecked()){
                    smileyImage.setVisibility(View.VISIBLE);
                }
                else{
                    smileyImage.setVisibility(View.INVISIBLE);
                }
            }
        });


        Button generateBt = (Button)findViewById(R.id.generate_button);
        generateBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = dropDown.getSelectedItem().toString();
                _noun = noun.getText().toString();
                _noun2 = noun2.getText().toString();
                _adjective = adjective.getText().toString();
                _adjective2 = adjective2.getText().toString();
                _food = food.getText().toString();
                _bodypart = bodypart.getText().toString();
                _verb = verb.getText().toString();
                _verb2 = verb2.getText().toString();

                TextView storyText = (TextView) findViewById(R.id.story_text_view);
                if(_noun == "a" || _noun2 == "a" || _adjective == "a" || _adjective2 == "a" || _food == "a" || _bodypart == "a" || _verb == "a" || _verb2 == "a"){
                    Toast toast = Toast.makeText(getApplicationContext(), "You must fill all the options to show the story", 10);
                    toast.show();
                }
                else{
                    storyText.setText("Here are a few things to do for fun. Start a game of touch " +_bodypart + " ball. Put a " + _noun + " in someone's lunch bag. Start a "
                            + _food + " fight in the school "+ _adjective +" room. Choose sides and have a " +_verb + " ball competition. Demand more " + _noun2+ " and more " + _adjective2 +
                            " classes. Choose " + text +" kids to be 'it' at " + _verb2);
                }


                // check to make sure every string has a value
                // if not, pop up a toast, saying not every string has a value
                // otherwise, fill out the string which contains the story

            }
        });


    }
}
