package net.calebwright.testapp1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Pulled mad lib template from https://www.woojr.com/mad-libs-worksheets/school-mad-libs-recess/
    String _noun = "";
    String _noun2 = "";
    String _adjective = "";
    String _adjective2 = "";
    String _food = "";
    String _bodypart = "";
    String _verb = "";
    String _verb2 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        final EditText noun = (EditText) findViewById(R.id.noun);
        final EditText noun2 = (EditText) findViewById(R.id.plural_noun);
        final EditText adjective = (EditText) findViewById(R.id.adjective1);
        final EditText adjective2 = (EditText) findViewById(R.id.adjective2);
        final EditText food = (EditText) findViewById(R.id.food);
        final EditText bodypart = (EditText) findViewById(R.id.body_part);
        final EditText verb = (EditText) findViewById(R.id.verb1);
        final EditText verb2 = (EditText) findViewById(R.id.verb2);
        final Spinner dropDown = (Spinner) findViewById(R.id.drop_down);

        _noun = noun.getText().toString();
        _noun2 = noun2.getText().toString();
        _adjective = adjective.getText().toString();
        _adjective2 = adjective2.getText().toString();
        _food = food.getText().toString();
        _bodypart = bodypart.getText().toString();
        _verb = verb.getText().toString();
        _verb2 = verb2.getText().toString();
        // set dropdown here
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button generateBt = (Button)findViewById(R.id.generate_button);
        generateBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView storyText = (TextView) findViewById(R.id.story_text_view);
                if(_noun == "" || _noun2 == "" || _adjective == "" || _adjective2 == "" || _food == "" || _bodypart == "" || _verb == "" || _verb2 == ""){
                    Toast toast = Toast.makeText(getApplicationContext(), "You must fill all the options to show the story", Toast.LENGTH_LONG);
                    toast.show();
                }
                else{
                    storyText.setText("Here are a few things to do for fun. Start a game of touch " +_bodypart + " ball. Put a " + _noun + " in someone's lunch bag. Start a "
                            + _food + " fight in the school "+ _adjective +" room. Choose sides and have a " +_verb + " ball competition. Demand more " + _noun2+ " and more " + _adjective2 +
                            " classes. Choose ### kids to be 'it' at " + _verb2);
                }
                // check to make sure every string has a value
                // if not, pop up a toast, saying not every string has a value
                // otherwise, fill out the string which contains the story

            }
        });

    }
}
