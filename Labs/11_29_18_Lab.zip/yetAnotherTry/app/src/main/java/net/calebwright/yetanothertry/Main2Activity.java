package net.calebwright.yetanothertry;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static android.provider.CalendarContract.CalendarCache.URI;

public class Main2Activity extends AppCompatActivity {
    private String siteURL;
    private String siteName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();
        siteURL = intent.getStringExtra("siteURL");
        siteName = intent.getStringExtra("siteName");
        Log.i("site received: ", siteName);
        Log.i("URL received: ", siteURL);
        TextView myMessage=findViewById(R.id.pg2instructions);
        myMessage.setText("The best site for you is " + siteName);
        setUpGoButton();
    }

    private void setUpGoButton(){
        Button goButton= (Button) findViewById(R.id.goButton);
        goButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadSite(v);
            }
        });
    }
    private void loadSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(URI.parse(siteURL));
        startActivity(intent);
    }
}
