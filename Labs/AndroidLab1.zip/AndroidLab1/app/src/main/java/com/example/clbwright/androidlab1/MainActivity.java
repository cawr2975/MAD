package com.example.clbwright.androidlab1;

import android.support.annotation.DrawableRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int counter = 0;
    String name = "none";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText userName;
        userName = (EditText) findViewById(R.id.userNameInput);

        Button tellJoke = (Button) findViewById(R.id.jokeButton);
        tellJoke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = userName.getText().toString();
                TextView jokeTextView = (TextView) findViewById(R.id.jokeText);
                TextView answerTextView = (TextView) findViewById(R.id.answerText);
                ImageView jokeImage= (ImageView) findViewById(R.id.jokeImage);
                if(counter == 0) {
                    jokeTextView.setText(name + "why are teddy Bears never hungry?");
                    System.out.println(name);
                    jokeImage.setImageResource(R.color.white);
                }
                else if(counter == 1){
                    jokeTextView.setText(name + "what did one toilet say to the other toilet?");
                    jokeImage.setImageResource(R.color.white);
                }
                else if(counter == 2){
                    jokeTextView.setText(name + "when is the best time to go to the dentist?");
                    jokeImage.setImageResource(R.color.white);
                }
                else if(counter == 3){
                    jokeTextView.setText(name + "where do beef burgers go to dance?");
                    jokeImage.setImageResource(R.color.white);
                }
                else if(counter == 4){
                    jokeTextView.setText(name + "what do you call a T-Rex that has been beaten up? ");
                    jokeImage.setImageResource(R.color.white);
                    counter = -1;
                }
                counter++;
                answerTextView.setText("");
            }
        });

        Button tellAnswer = (Button) findViewById(R.id.answerButton);
        tellAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView jokeTextView = (TextView) findViewById(R.id.jokeText);
                TextView answerTextView = (TextView) findViewById(R.id.answerText);
                ImageView jokeImage= (ImageView) findViewById(R.id.jokeImage);
                if(counter == 1) {
                    answerTextView.setText("Because they are always stuffed!");
                    ImageView img= (ImageView) findViewById(R.id.jokeImage);
                    jokeImage.setImageResource(R.drawable.teddy);
                }
                else if(counter == 2){
                    answerTextView.setText("You look flushed!");
                    jokeImage.setImageResource(R.drawable.toilet);
                }
                else if(counter == 3){
                    answerTextView.setText("Tooth-hurty!");
                    jokeImage.setImageResource(R.drawable.tooth);
                }
                else if(counter == 4){
                    answerTextView.setText("The meatball!");
                    jokeImage.setImageResource(R.drawable.burger);
                }
                else if(counter == 0){
                    answerTextView.setText("A Dino-sore!");
                    jokeImage.setImageResource(R.drawable.trex);
                }
            }
        });
    }
}
