package net.calebwright.finalproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
        String ac1;
        String ac2;
        String ac3;
        String ac4;
        String ac5;
        String ac6;

        TextView ac_1;
        TextView ac_2;
        TextView ac_3;
        TextView ac_4;
        TextView ac_5;
        TextView ac_6;

        TextView ans1_txt;
        TextView ans2_txt;
        TextView ans3_txt;
        TextView ans4_txt;
        TextView ans5_txt;
        TextView ans6_txt;

        private int ans1;
        private int ans2;
        private int ans3;
        private int ans4;
        private int ans5;
        private int ans6;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();
        ans1 = intent.getIntExtra("answer1", 0);
        ans2 = intent.getIntExtra("answer2", 0);
        ans3 = intent.getIntExtra("answer3", 0);
        ans4 = intent.getIntExtra("answer4", 0);
        ans5 = intent.getIntExtra("answer5", 0);
        ans6 = intent.getIntExtra("answer6", 0);
        setUpText();
    }
    private void setUpText(){
        ac1 = getString(R.string.activity_1);
        ac2 = getString(R.string.activity_2);
        ac3 = getString(R.string.activity_3);
        ac4 = getString(R.string.activity_4);
        ac5 = getString(R.string.activity_5);
        ac6 = getString(R.string.activity_6);
        ac_1 = findViewById(R.id.pg2_activity1_textview);
        ac_1.setText(ac1);
        ac_2 = findViewById(R.id.pg2_activity2_textview);
        ac_2.setText(ac2);
        ac_3 = findViewById(R.id.pg2_activity3_textview);
        ac_3.setText(ac3);
        ac_4 = findViewById(R.id.pg2_activity4_textview);
        ac_4.setText(ac4);
        ac_5 = findViewById(R.id.pg2_activity5_textview);
        ac_5.setText(ac5);
        ac_6 = findViewById(R.id.pg2_activity6_textview);
        ac_6.setText(ac6);
        ans1_txt = findViewById(R.id.ac1_ans);
        ans1_txt.setText(String.valueOf(ans1)+ " minutes");
        ans2_txt = findViewById(R.id.ac2_ans);
        ans2_txt.setText(String.valueOf(ans2) + " minutes");
        ans3_txt = findViewById(R.id.ac3_ans);
        ans3_txt.setText(String.valueOf(ans3)+ " minutes");
        ans4_txt = findViewById(R.id.ac4_ans);
        ans4_txt.setText(String.valueOf(ans4)+ " minutes");
        ans5_txt = findViewById(R.id.ac5_ans);
        ans5_txt.setText(String.valueOf(ans5)+ " minutes");
        ans6_txt = findViewById(R.id.ac6_ans);
        ans6_txt.setText(String.valueOf(ans6)+ " minutes");
    }

}
