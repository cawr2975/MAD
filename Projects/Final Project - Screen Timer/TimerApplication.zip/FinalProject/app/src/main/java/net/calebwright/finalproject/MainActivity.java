package net.calebwright.finalproject;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.ColorRes;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
//import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private TextView countDownText;
    private Button countDownButton;
    private Button historyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab); // I left the floating action button fairly small, and added a magnifying glass icon. I had a hard time figuring out how to make other icons fit.
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                intent.putExtra("answer1", cnt1);
                intent.putExtra("answer2", cnt2);
                intent.putExtra("answer3", cnt3);
                intent.putExtra("answer4", cnt4);
                intent.putExtra("answer5", cnt5);
                intent.putExtra("answer6", cnt6);
                //intent.putExtra("siteURL", myURL);
                startActivity(intent);
            }
        });
        setUpButtons();
        countDownText = findViewById(R.id.countDownText);
        countDownButton = findViewById(R.id.startButton);
//        historyButton = findViewById(R.id.hist_button);
        updateTimer();
    }
    private CountDownTimer countDownTimer;
    private long timeLeft = 600000; // start the timer with 10 minutes of free screen time each day. He has to earn more screen time by doing activities.
    private boolean timerIsRunning; // a bool to check if the timer is running or not.

    private void setUpButtons(){
        setUpActivity1();
        setUpActivity2();
        setUpActivity3();
        setUpActivity4();
        setUpActivity5();
        setUpActivity6();
        setUpStartButton();
//        setUpHistoryButton();
//        setUpStopButton();
    }
    int activity1Time = 15;
    int activity2Time = 15;
    int activity3Time = 20;
    int activity4Time = 20;
    int activity5Time = 10;
    int activity6Time = 10;
    int cnt1 = 0;
    int cnt2 = 0;
    int cnt3 = 0;
    int cnt4 = 0;
    int cnt5 = 0;
    int cnt6 = 0;

    public void startStop(){
        if(timerIsRunning){
            stopTimer();
        }
        else{
            startTimer();
        }
    }
    public void stopTimer(){
        countDownTimer.cancel();
        countDownButton.setText("Start");
        countDownButton.setBackgroundColor(Color.GREEN);
        timerIsRunning = false;
    }
    public void startTimer(){
        countDownTimer = new CountDownTimer(timeLeft, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeft = millisUntilFinished;
                updateTimer();
            }

            @Override
            public void onFinish() {

            }
        }.start();
        countDownButton.setText("Stop");
        countDownButton.setBackgroundColor(Color.RED);
        timerIsRunning = true;
    }

    public void updateTimer(){
        int minutes = (int) timeLeft/60000;
        int seconds = (int) timeLeft%60000 / 1000;
        String timeLeftText;
        timeLeftText = "" + minutes + ":";
        if(seconds < 10){
            timeLeftText += "0";
        }
        timeLeftText += seconds;
        countDownText.setText(timeLeftText);
        if(minutes == 0 && seconds == 1){ // I had to do this, otherwise the timer would just hit 0:01 and stop. It would never reach zero.
//            timeLeftText = "0:01";
//            countDownText.setText(timeLeftText);
//            try {
//                TimeUnit.SECONDS.sleep(1);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            timeLeftText = "0:00";
//            countDownText.setText(timeLeftText);
            Toast.makeText(MainActivity.this, "Time has run out!", Toast.LENGTH_LONG).show();
        }
    }
    private void setUpStartButton(){
        Button startButton = (Button) findViewById(R.id.startButton);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Start Button Clicked", Toast.LENGTH_LONG).show();
                startStop();
            }
        });
    }
    private void setUpActivity1(){
        Button activity1 = (Button) findViewById(R.id.activity1);
        String buttonText = getString(R.string.activity_1);
        activity1.setText(buttonText + "\n\n" + activity1Time);
        activity1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timerIsRunning){
                    Toast.makeText(MainActivity.this, "Unable to add time with timer running. Please stop the timer to add more time", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(MainActivity.this, "Activity1 Button Clicked", Toast.LENGTH_LONG).show();
                timeLeft = timeLeft + (activity1Time * 60000);
                int minutes = (int) timeLeft/60000;
                int seconds = (int) timeLeft%60000 / 1000;
                String timeLeftText;
                timeLeftText = "" + minutes + ":";
                if(seconds < 10){
                    timeLeftText += "0";
                }
                timeLeftText += seconds;
                countDownText.setText(timeLeftText);
                cnt1 += activity1Time;
            }
        });
    }
    private void setUpActivity2(){
        Button activity2 = (Button) findViewById(R.id.activity2);
        String buttonText = getString(R.string.activity_2);
        activity2.setText(buttonText + "\n\n" + activity2Time);
        activity2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timerIsRunning){
                    Toast.makeText(MainActivity.this, "Unable to add time with timer running. Please stop the timer to add more time", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(MainActivity.this, "Activity2 Button Clicked", Toast.LENGTH_LONG).show();
                timeLeft = timeLeft + (activity2Time * 60000);
                int minutes = (int) timeLeft/60000;
                int seconds = (int) timeLeft%60000 / 1000;
                String timeLeftText;
                timeLeftText = "" + minutes + ":";
                if(seconds < 10){
                    timeLeftText += "0";
                }
                timeLeftText += seconds;
                countDownText.setText(timeLeftText);
                cnt2 += activity2Time;
            }
        });
    }
    private void setUpActivity3(){
        Button activity3 = (Button) findViewById(R.id.activity3);
        String buttonText = getString(R.string.activity_3);
        activity3.setText(buttonText + "\n\n" + activity3Time);
        activity3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timerIsRunning){
                    Toast.makeText(MainActivity.this, "Unable to add time with timer running. Please stop the timer to add more time", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(MainActivity.this, "Activity3 Button Clicked", Toast.LENGTH_LONG).show();
                timeLeft = timeLeft + (activity3Time * 60000);
                int minutes = (int) timeLeft/60000;
                int seconds = (int) timeLeft%60000 / 1000;
                String timeLeftText;
                timeLeftText = "" + minutes + ":";
                if(seconds < 10){
                    timeLeftText += "0";
                }
                timeLeftText += seconds;
                countDownText.setText(timeLeftText);
                cnt3 += activity3Time;
            }
        });
    }
    private void setUpActivity4(){
        Button activity4 = (Button) findViewById(R.id.activity4);
        String buttonText = getString(R.string.activity_4);
        activity4.setText(buttonText + "\n\n" + activity4Time);
        activity4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timerIsRunning){
                    Toast.makeText(MainActivity.this, "Unable to add time with timer running. Please stop the timer to add more time", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(MainActivity.this, "Activity4 Button Clicked", Toast.LENGTH_LONG).show();
                timeLeft = timeLeft + (activity4Time * 60000);
                int minutes = (int) timeLeft/60000;
                int seconds = (int) timeLeft%60000 / 1000;
                String timeLeftText;
                timeLeftText = "" + minutes + ":";
                if(seconds < 10){
                    timeLeftText += "0";
                }
                timeLeftText += seconds;
                countDownText.setText(timeLeftText);
                cnt4 += activity4Time;
            }
        });
    }
    private void setUpActivity5(){
        Button activity5 = (Button) findViewById(R.id.activity5);
        String buttonText = getString(R.string.activity_5);
        activity5.setText(buttonText + "\n\n" + activity5Time);
        activity5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timerIsRunning){
                    Toast.makeText(MainActivity.this, "Unable to add time with timer running. Please stop the timer to add more time", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(MainActivity.this, "Activity5 Button Clicked", Toast.LENGTH_LONG).show();
                timeLeft = timeLeft + (activity5Time * 60000);
                int minutes = (int) timeLeft/60000;
                int seconds = (int) timeLeft%60000 / 1000;
                String timeLeftText;
                timeLeftText = "" + minutes + ":";
                if(seconds < 10){
                    timeLeftText += "0";
                }
                timeLeftText += seconds;
                countDownText.setText(timeLeftText);
                cnt5 += activity5Time;
            }
        });
    }
    private void setUpActivity6(){
        Button activity6 = (Button) findViewById(R.id.activity6);
        String buttonText = getString(R.string.activity_6);
        activity6.setText(buttonText + "\n\n" + activity6Time);
        activity6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(timerIsRunning){
                    Toast.makeText(MainActivity.this, "Unable to add time with timer running. Please stop the timer to add more time", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(MainActivity.this, "Activity6 Button Clicked", Toast.LENGTH_LONG).show();
                timeLeft = timeLeft + (activity6Time * 60000);
                int minutes = (int) timeLeft/60000;
                int seconds = (int) timeLeft%60000 / 1000;
                String timeLeftText;
                timeLeftText = "" + minutes + ":";
                if(seconds < 10){
                    timeLeftText += "0";
                }
                timeLeftText += seconds;
                countDownText.setText(timeLeftText);
                cnt6 += activity6Time;
            }
        });
    }
//    private void setUpHistoryButton(){
//        Button historyButton = (Button) findViewById(R.id.hist_button);
//        historyButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // launch a new intent and pass in the activity counts
//            }
//        });
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        Toast.makeText(MainActivity.this, "Pressed action button", Toast.LENGTH_LONG).show();
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
